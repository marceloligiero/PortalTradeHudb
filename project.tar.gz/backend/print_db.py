from app.config import settings
print(settings.DATABASE_URL)
