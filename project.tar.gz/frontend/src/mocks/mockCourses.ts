// mockCourses removed — replaced by real API data in StudentCoursesPage

